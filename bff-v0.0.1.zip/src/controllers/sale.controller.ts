import { Request, Response } from 'express';
import { Sale } from '../models/Sale';
import { Client } from '../models/Client';
import { asyncHandler } from '../utils/asyncHandler';

export const createSale = asyncHandler(async (req: Request, res: Response) => {
  const { client, products, total } = req.body;
  const sale = new Sale({ client, products, total });
  await sale.save();
  await Client.findByIdAndUpdate(client, { $inc: { debt: total } });
  res.status(201).json(sale);
});

export const getSalesByClient = asyncHandler(
  async (req: Request, res: Response) => {
    const sales = await Sale.find({ client: req.params.id }).populate(
      'products.product'
    );
    res.json(sales);
  }
);
