import { Request, Response } from 'express';
import { Payment } from '../models/Payment';
import { Client } from '../models/Client';
import { asyncHandler } from '../utils/asyncHandler';

export const createPayment = asyncHandler(
  async (req: Request, res: Response) => {
    const { client, amount } = req.body;

    const payment = new Payment({ client, amount });
    await payment.save();

    await Client.findByIdAndUpdate(client, {
      $inc: { debt: -amount, credit: amount },
    });

    res.status(201).json(payment);
  }
);

export const getPaymentsByClient = asyncHandler(
  async (req: Request, res: Response) => {
    const payments = await Payment.find({ client: req.params.id });
    res.json(payments);
  }
);
