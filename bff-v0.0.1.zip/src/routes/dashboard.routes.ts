import { Router } from 'express';
import { authenticateToken } from '../middlewares/auth';
import { getDashboard } from '../controllers/dashboard.controller';

const router = Router();

router.use(authenticateToken);
router.get('/', getDashboard);

export default router;
