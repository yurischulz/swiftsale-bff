import request from 'supertest';
import app from '../app';
import mongoose from 'mongoose';

let token: string;

beforeAll(async () => {
  await mongoose.connect(process.env.MONGO_URI || '', {});
  await request(app).post('/auth/register').send({ email: 'clienttest@example.com', password: '12345678' });
  const res = await request(app).post('/auth/login').send({ email: 'clienttest@example.com', password: '12345678' });
  token = res.body.token;
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('Client endpoints', () => {
  let clientId: string;

  it('should create a client', async () => {
    const res = await request(app)
      .post('/clients')
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'Cliente Teste', phone: '999999999', address: 'Rua A' });
    expect(res.statusCode).toEqual(201);
    clientId = res.body._id;
  });

  it('should get clients', async () => {
    const res = await request(app)
      .get('/clients')
      .set('Authorization', `Bearer ${token}`);
    expect(res.statusCode).toEqual(200);
  });

  it('should update a client', async () => {
    const res = await request(app)
      .put(`/clients/${clientId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ phone: '888888888' });
    expect(res.statusCode).toEqual(200);
    expect(res.body.phone).toBe('888888888');
  });

  it('should delete a client', async () => {
    const res = await request(app)
      .delete(`/clients/${clientId}`)
      .set('Authorization', `Bearer ${token}`);
    expect(res.statusCode).toEqual(204);
  });
});
