import request from 'supertest';
import app from '../app';
import mongoose from 'mongoose';

describe('Auth endpoints', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGO_URI || '', {});
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  it('should register a new user', async () => {
    const res = await request(app)
      .post('/auth/register')
      .send({ email: 'testuser@example.com', password: 'password123' });
    expect(res.statusCode).toEqual(201);
  });

  it('should login the user', async () => {
    const res = await request(app)
      .post('/auth/login')
      .send({ email: 'testuser@example.com', password: 'password123' });
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('token');
  });
});
