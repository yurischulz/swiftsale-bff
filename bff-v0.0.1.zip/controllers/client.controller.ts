import {{ asyncHandler }} from '../utils/asyncHandler';

import { Request, Response } from 'express';
import { Client } from '../models/Client';

export const getAllClients = asyncHandler(async (req: Request, res: Response) => {
  const clients = await Client.find().populate('affiliation');
  res.json(clients);
};

export const createClient = asyncHandler(async (req: Request, res: Response) => {
  const client = new Client(req.body);
  await client.save();
  res.status(201).json(client);
};

export const updateClient = asyncHandler(async (req: Request, res: Response) => {
  const client = await Client.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json(client);
};

export const deleteClient = asyncHandler(async (req: Request, res: Response) => {
  await Client.findByIdAndDelete(req.params.id);
  res.status(204).send();
};
