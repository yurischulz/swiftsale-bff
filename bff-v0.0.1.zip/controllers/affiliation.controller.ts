import {{ asyncHandler }} from '../utils/asyncHandler';

import { Request, Response } from 'express';
import { Affiliation } from '../models/Affiliation';
import { Client } from '../models/Client';

export const getAllAffiliations = asyncHandler(async (req: Request, res: Response) => {
  const affiliations = await Affiliation.find();
  const enriched = await Promise.all(
    affiliations.map(async (aff) => {
      const clients = await Client.find({ affiliation: aff._id });
      const totalDebt = clients.reduce((sum, c) => sum + c.debt, 0);
      return { ...aff.toObject(), totalDebt };
    })
  );
  res.json(enriched);
};

export const createAffiliation = asyncHandler(async (req: Request, res: Response) => {
  const affiliation = new Affiliation(req.body);
  await affiliation.save();
  res.status(201).json(affiliation);
};

export const updateAffiliation = asyncHandler(async (req: Request, res: Response) => {
  const affiliation = await Affiliation.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );
  res.json(affiliation);
};

export const deleteAffiliation = asyncHandler(async (req: Request, res: Response) => {
  await Affiliation.findByIdAndDelete(req.params.id);
  res.status(204).send();
};
