# Product Routes

## GET /products
Lista todos os produtos.

## POST /products
Cria um novo produto.

**Body**:
```json
{
  "name": "Produto A",
  "unitPrice": 50
}
```

## PUT /products/:id
Atualiza um produto.

## DELETE /products/:id
Remove um produto.
