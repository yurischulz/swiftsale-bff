# Sale Routes

## POST /sales
Registra uma nova venda para um cliente.

**Body**:
```json
{
  "client": "client_id",
  "products": [
    { "product": "product_id", "quantity": 2, "unitPrice": 100 }
  ],
  "total": 200
}
```

## GET /sales/by-client/:id
Lista as vendas de um cliente.
