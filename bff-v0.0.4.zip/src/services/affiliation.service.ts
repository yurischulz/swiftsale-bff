import { Affiliation } from '../models/Affiliation';

export async function getAllAffiliations() {
  return await Affiliation.find();
}

export async function createAffiliation(data: any) {
  const affiliation = new Affiliation(data);
  return await affiliation.save();
}

export async function updateAffiliation(id: string, data: any) {
  return await Affiliation.findByIdAndUpdate(id, data, { new: true });
}

export async function deleteAffiliation(id: string) {
  return await Affiliation.findByIdAndDelete(id);
}
