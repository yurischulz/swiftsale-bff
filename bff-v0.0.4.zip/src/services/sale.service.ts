import { Sale } from '../models/Sale';


export async function createSale(data: any) {
  const sale = new Sale(data);
  return await sale.save();
}

export async function getAllSales() {
  return await Sale.find();
}