# Auth Routes

## POST /auth/register
Registra um novo usuário.

**Body**:
```json
{
  "email": "user@example.com",
  "password": "senha123"
}
```

## POST /auth/login
Autentica o usuário e retorna um token JWT.

**Body**:
```json
{
  "email": "user@example.com",
  "password": "senha123"
}
```

**Response**:
```json
{
  "token": "jwt_token_aqui"
}
```
