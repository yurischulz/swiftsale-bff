# Affiliation Routes

## GET /affiliations
Lista todas as afiliações e seus saldos acumulados.

## POST /affiliations
Cria uma nova afiliação.

**Body**:
```json
{
  "name": "Instituição ABC",
  "address": "Rua X",
  "phone": "123456789"
}
```

## PUT /affiliations/:id
Atualiza uma afiliação.

## DELETE /affiliations/:id
Remove uma afiliação.
