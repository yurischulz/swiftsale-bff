# Payment Routes

## POST /payments
Registra um pagamento de um cliente.

**Body**:
```json
{
  "client": "client_id",
  "amount": 100
}
```

## GET /payments/by-client/:id
Lista os pagamentos de um cliente.
