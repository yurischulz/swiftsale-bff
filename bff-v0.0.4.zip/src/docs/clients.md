# Client Routes

## GET /clients
Lista todos os clientes.

## POST /clients
Cria um novo cliente.

**Body**:
```json
{
  "name": "Cliente Nome",
  "phone": "999999999",
  "address": "Rua Exemplo",
  "email": "cliente@exemplo.com",
  "notes": "observações",
  "affiliation": "affiliation_id"
}
```

## PUT /clients/:id
Atualiza um cliente existente.

## DELETE /clients/:id
Remove um cliente.
