import { describe, it, expect } from '@jest/globals';
import * as service from '../services/product.service';

describe('product.service service', () => {
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
