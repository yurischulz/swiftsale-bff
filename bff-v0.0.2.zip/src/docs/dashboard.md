# Dashboard Route

## GET /dashboard
Retorna os top 5 clientes e afiliações com maior saldo devedor.
