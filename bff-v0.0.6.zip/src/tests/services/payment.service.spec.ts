import { describe, it, expect } from '@jest/globals';
import * as service from '../services/payment.service';

describe('payment.service service', () => {
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
