import { describe, it, expect } from '@jest/globals';
import * as service from '../services/dashboard.service';

describe('dashboard.service service', () => {
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
