import { Payment } from '../models/Payment';


export async function createPayment(data: any) {
  const payment = new Payment(data);
  return await payment.save();
}

export async function getPaymentsByClient(id: string) {
  return await Payment.find({ client: id });
}