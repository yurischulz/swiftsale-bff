import { Payment } from '../models/Payment';
import { Sale } from '../models/Sale';
import { Client } from '../models/Client';

export async function getDashboardSummary() {
  return {
    totalClients: await Client.countDocuments(),
    totalPayments: await Payment.countDocuments(),
    totalSales: await Sale.countDocuments(),
  }; // Implement with aggregation if needed
}
