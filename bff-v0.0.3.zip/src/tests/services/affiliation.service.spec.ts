import { describe, it, expect } from '@jest/globals';
import * as service from '../services/affiliation.service';

describe('affiliation.service service', () => {
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
