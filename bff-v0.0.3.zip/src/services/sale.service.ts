import { Sale } from '../models/Sale';


export const async function createSale(data: any) {
  const sale = new Sale(data);
  return await sale.save();
}

async function getAllSales() {
  return await Sale.find();
}
