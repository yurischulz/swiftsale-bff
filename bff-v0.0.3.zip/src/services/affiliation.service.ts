import { Affiliation } from '../models/Affiliation';
import { Client } from '../models/Client';

export const async function getAllAffiliations() {
  return await Affiliation.find();
}

async function createAffiliation(data: any) {
  const affiliation = new Affiliation(data);
  return await affiliation.save();
}

async function updateAffiliation(id: string, data: any) {
  return await Affiliation.findByIdAndUpdate(id, data, { new: true });
}

async function deleteAffiliation(id: string) {
  return await Affiliation.findByIdAndDelete(id);
}
