import { Product } from '../models/Product';


export const async function getAllProducts() {
  return await Product.find();
}

async function createProduct(data: any) {
  const product = new Product(data);
  return await product.save();
}

async function updateProduct(id: string, data: any) {
  return await Product.findByIdAndUpdate(id, data, { new: true });
}

async function deleteProduct(id: string) {
  return await Product.findByIdAndDelete(id);
}
